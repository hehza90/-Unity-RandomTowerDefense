﻿using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(MapGenerator))]
public class MapGeneratorInspector : Editor {

    public override void OnInspectorGUI()
    {
        DrawDefaultInspector();

        if (GUILayout.Button("Generate Map by Xml"))
        {
            MapGenerator mapGenerator = (MapGenerator)target;
            mapGenerator.GenerateMapByXml();
        }
    }
}
