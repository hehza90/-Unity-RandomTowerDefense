﻿using UnityEngine;
using UnityEditor;

[CustomEditor(typeof(WaveSpawner))]
public class WaveSpawnerInspector : Editor
{
    public override void OnInspectorGUI()
    {
        DrawDefaultInspector();

        if (GUILayout.Button("Set WaveList By Xml"))
        {
            WaveSpawner waveSpawner = (WaveSpawner)target;
            waveSpawner.SetWaveByXml();
        }
    }

}
