﻿using UnityEngine;
using System.Collections;

public class CameraController : MonoBehaviour {

    //카메라가 이동할 거리
    private Vector3 movePosition;
    //터치 위치
    private Vector2 curScreenPos, preScreenPos;

    #region UnityInspector
    //실행시 처음 위치
    public Vector3 firstPosition;
    
    //카메라 위치 제한
    [Header("POSITION LIMITATION")]
    public float minX = -10f;
    public float maxX = 10f;
    public float minY = -10f;
    public float maxY = 10f;
    public float minZ = -10f;
    public float maxZ = 10f;

    [Header("MOBILE_ANDROID")]   
    public float zoomSpeed = 5f; //줌속도
    public float flatSpeed =5;    //상하좌우 이동 속도
    
    [Header("PC, UNITY EDITOR")]
    public float panSpeed = 30f;                //키보드 좌우 이동속도
    public float panBorderThickness = 10f;       //가장자리로부터 이동을하는 영역
    public float scrollSpeed = 5f;             //스크롤 속도

    #endregion UnityInspector

    //==========Awake()==========
    void Awake()
    {        
        this.transform.position= firstPosition;
    }

    //==========Update()==========
    void Update()
    {
        if (GameManager.SingleTon.GameOver)
        {
            this.enabled = false;
            return;
        }

        #region CameraMovement

#if UNITY_ANDROID
        //if (Input.touchCount == 0)
        //{
        //    movePosition = Vector3.zero;
        //}
        #region Zoom
        // 터치가 2개 일때
        if (Input.touchCount == 2)
        {
            Touch touchZero = Input.GetTouch(0);   //0번째 터지
            Touch touchOne = Input.GetTouch(1);    //1번째 터지

            // Find the position in the previous frame of each touch.
            //각터치의 이전 프래임의 위치를 구함
            Vector2 touchZeroPrevPos = touchZero.position - touchZero.deltaPosition;
            Vector2 touchOnePrevPos = touchOne.position - touchOne.deltaPosition;

            // Find the magnitude of the vector (the distance) between the touches in each frame.
            //이전 프래임의 터치간 거리를 구함
            float prevTouchDeltaMag = (touchZeroPrevPos - touchOnePrevPos).magnitude;
            //현재 프래임의 2개 터치간 거리   
            float touchDeltaMag = (touchZero.position - touchOne.position).magnitude;
            //두 거리의 차이를 구함
            float deltaMagnitudeDiff = prevTouchDeltaMag - touchDeltaMag;

            //이동
            movePosition = new Vector3(0, deltaMagnitudeDiff * zoomSpeed * Time.deltaTime, 0);
        }
        #endregion Zoom
        
        #region Move
        if (Input.touchCount == 1)
        {
            Touch touch = Input.GetTouch(0);        

            if (touch.phase == TouchPhase.Moved)
            {
                //이전 프래임의 터치 위치
                preScreenPos = touch.position - touch.deltaPosition;
                //현재 프래임 위치
                curScreenPos = touch.position;
                
                //이동할 위치  -(현재위치 - 이전위치)* 스피드                               
                Vector3 tempVector = (Vector3)(preScreenPos - curScreenPos) * (Time.deltaTime) * flatSpeed;
                movePosition = new Vector3(tempVector.x, 0, tempVector.y);
                //movePosition.x = tempVector.x;
                //movePosition.y = tempVector.z;
                //movePosition.z = tempVector.y;
            }
        }
        #endregion Move
       
#endif

        
#if UNITY_EDITOR

        #region Zoom

        float scroll = Input.GetAxis("Mouse ScrollWheel");    
        movePosition = new Vector3(0, -scroll * 1000 * scrollSpeed * Time.deltaTime, 0);
       
        #endregion Zoom
        
        #region Move
        //키보드 WASD로 이동과 마우스로 화면 가장자리 이동
        if (Input.GetKey("w") || Input.mousePosition.y >= Screen.height - panBorderThickness)
        {
            movePosition = Vector3.forward * panSpeed * Time.deltaTime;         
        }
        if (Input.GetKey("s") || Input.mousePosition.y <= panBorderThickness)
        {
            movePosition = Vector3.back * panSpeed * Time.deltaTime;        
        }
        if (Input.GetKey("d") || Input.mousePosition.x >= Screen.width - panBorderThickness)
        {
            movePosition = Vector3.right * panSpeed * Time.deltaTime;          
        }
        if (Input.GetKey("a") || Input.mousePosition.x <= panBorderThickness)
        {
            movePosition = Vector3.left * panSpeed * Time.deltaTime;          
        }

        #endregion Move

#endif

        //앞서 구한 movePosition만큼 이동
        this.transform.Translate(movePosition, Space.World);

        //카메라 위치 제한
        this.transform.position = new Vector3
            ( Mathf.Clamp(this.transform.position.x, firstPosition.x+minX, firstPosition.x+ maxX),
            Mathf.Clamp(this.transform.position.y, firstPosition.y + minY, firstPosition.y +maxY),
            Mathf.Clamp(this.transform.position.z, firstPosition.z + minZ, firstPosition.z + maxZ));

        //이동 초기화
        movePosition = Vector3.zero;

        #endregion CameraMovement



    }

}
