﻿using UnityEngine;
using System.Collections;

public class BonusEnemy : Enemy {
    
    public float rewardMoney;
    public float coolTime;

    override public void Die()
    {        
        base.Die();
        Player.SingleTon.ChangeMoney(rewardMoney);
    }


}
