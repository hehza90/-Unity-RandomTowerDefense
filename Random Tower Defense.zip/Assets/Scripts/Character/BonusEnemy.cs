﻿using UnityEngine;
using System.Collections;

public class BonusEnemy : Enemy {
    
    public float rewardMoney;
    public float coolTime;

    public override void Die()
    {        
        base.Die();
        Player.SingleTon.ChangeMoney(rewardMoney);
    }





}
