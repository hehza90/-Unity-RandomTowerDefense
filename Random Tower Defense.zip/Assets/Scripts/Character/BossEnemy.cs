﻿using UnityEngine;
using System.Collections;

public class BossEnemy : Enemy{


    public float rewardSpecialPoint = 1;

    override public void Die()
    {
        base.Die();
        Player.SingleTon.ChangeSpecialPoint(rewardSpecialPoint);
    }
}
