﻿using UnityEngine;
using System.Collections;

public class BossEnemy : Enemy{


    public float rewardSpecialPoint = 1;

    public override void Die()
    {
        base.Die();
        Player.SingleTon.ChangeSpecialPoint(rewardSpecialPoint);
    }
}
