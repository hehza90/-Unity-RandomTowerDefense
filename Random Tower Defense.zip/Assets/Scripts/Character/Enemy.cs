﻿using UnityEngine;
using System.Collections;
using System;

public class Enemy : Life{

    public GameObject model;           //눈에 보이는 모델
    public GameObject HPBar;           //HP바

    private float speed =10;
    private float damage= 1;            //목적지에 도달시 플레이 라이프 차감 수
      
    private Transform moveTarget;    //다음에 갈 위치
    private int waypointIndex = -1;


    //코드 경합 방지용
    private bool isActivate = false;

    //=======프로퍼티
    public float Speed
    {
        get
        {
            return speed;
        }
        set
        {
            speed = value;
        }
    }

    public float Damage
    {
        get
        {
            return damage;
        }
        set
        {
            damage = value;
        }
    }

    public bool IsActivate
    {
        get
        {
            return isActivate;
        }
        set
        {
            isActivate = value;
        }
    }



    //==============함수

    override public void TakeDamage(float damage)
    {
        //활성화 상태가 아니면 return
        if (isActivate == false)
            return;

        base.TakeDamage(damage);
    }

    void SetEnemyStat()
    {
        currenthealth = maxHealth;
    }


    //적이 죽을때
    public event Action whenEnemyDie;
    override public void Die()
    {
        base.Die();
        isActivate = false;
       
        if (whenEnemyDie != null)
        {
            whenEnemyDie();
        }
        Disapear();
    }


    //보이지 않게 하기
    public event Action whenEnemyDisappear;
    void Disapear()
    {
        model.SetActive(false);             //모델 끄기
        HPBar.SetActive(false);             //HP바 끄기
        Invoke("Deactive", 3.0f);
        //이벤트 실행
        if (whenEnemyDisappear != null)
        {
            whenEnemyDisappear();
        }
    }
    

     //비활성화
    void Deactive()
    {     
        this.gameObject.SetActive(false);
    }


    //다음 목적지로
    void GetNextWaypoint()
    {
        if(waypointIndex >= Waypoints.SingleTon.wayPoinList.Count - 1)
        {
            //끝까지 도달했을시 플레이어에게 데미지
            DamageToPlayer();            
            return;
        }
        //다음 웨이포인트 인덱스
        waypointIndex++;
        moveTarget = Waypoints.SingleTon.wayPoinList[waypointIndex];
        this.transform.LookAt(moveTarget);
    }
     

    //플레이어에게 데미지
    void DamageToPlayer()
    {
        Player.SingleTon.ChangeLives(-damage);
        isActivate = false;
        Disapear();
    }




    //========타임라인

    override protected void OnEnable()
    {
        base.OnEnable();

        //능력치 초기화
        SetEnemyStat();

        //이벤트 초기화
        whenEnemyDie = null;

        waypointIndex = -1;
        //황성화
        isActivate = true;

        GetNextWaypoint();
    }


    void Update()
    {

        if (isActivate == false || dead == true)
            return;

        //타겟까지 거리
        Vector3 dir = moveTarget.position - this.transform.position;
        //이동
        transform.Translate(dir.normalized * speed * Time.deltaTime, Space.World);
        //타겟과 충분히 가까워졌을때 다음 타겟으로
        if (Vector3.Distance(transform.position, moveTarget.position) <= 0.2f)
        {
            GetNextWaypoint();
        }
    }


}
