﻿using UnityEngine;
using System.Collections;
using System;

public class Life : MonoBehaviour, IDamageable
{

    public float maxHealth = 10;            //최대체력
    protected float currenthealth;              //현재체력

    [NonSerialized]
    public bool dead;                        //death 플래그

 
    //프로퍼티
    public float MaxHealth
    {
        get
        {
            return maxHealth;
        }
        set
        {
            maxHealth = value;
        }
    }

    public float Currenthealth
    {
        get
        {
            return currenthealth;
        }
        set
        {
            currenthealth = value;
        }
    }


    //=========OnEnable()============
    virtual protected void OnEnable()
    {
        //필드 초기화 
        SetHPFull();
        dead = false;
    }

    //데미지 받음

    virtual public void TakeDamage(float damage)
    {
        ChangeHP(-damage);

        if (currenthealth <= 0 && !dead)
        {
            Die();
        }      
    }

    public Action changeHP;
    public void ChangeHP(float amount)
    {      
        currenthealth += amount;

        if (changeHP != null)
        {
            changeHP();
        }
    }
    
    public void SetHPFull()
    {
        currenthealth = maxHealth;
        if (changeHP != null)
        {
            changeHP();
        }
    }

    //죽음
    virtual public void Die()
    {
        dead = true;
    }




}
