﻿using UnityEngine;
using System.Collections;
using System;

public class Life : MonoBehaviour, IDamageable
{

    public float maxHealth = 10;            //최대체력
    public float currenthealth;              //현재체력

    [NonSerialized]
    public bool dead;                        //death 플래그

    public event Action DeathEvent;          //죽었을때 여러 함수들을 등록 가능한 이벤트
    

    //=========OnEnable()============
    protected virtual void OnEnable()
    {
        //필드 초기화 
        SetHPFull();
        dead = false;
    }
    
    //데미지 받음
    
    public void TakeDamage(float damage)
    {
        ChangeHP(-damage);

        if (currenthealth <= 0 && !dead)
        {
            Die();
        }      
    }

    public Action changeHP;
    public void ChangeHP(float amount)
    {      
        currenthealth += amount;

        if (changeHP != null)
        {
            changeHP();
        }
    }
    
    public void SetHPFull()
    {
        currenthealth = maxHealth;
        if (changeHP != null)
        {
            changeHP();
        }
    }
    
    //죽음
    public virtual void Die()
    {
        dead = true;
        if (DeathEvent != null)
        {
            DeathEvent();        //죽었을때 이벤트 실행
        }
        this.gameObject.SetActive(false);
    }

}
