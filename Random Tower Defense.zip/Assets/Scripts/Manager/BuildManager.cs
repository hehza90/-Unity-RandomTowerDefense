﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

public class BuildManager : MonoBehaviour
{
    
    //타입에따른 업그래이드 저장용
    public Dictionary<Tower.TowerType, TypeUpgradeInfo> upgradeInfoDic = new Dictionary<Tower.TowerType, TypeUpgradeInfo>();

    //타입에 따른 색상 및 업그레이드 정보  upgradeInfoDic 의 Value
    [Serializable]
    public class TypeUpgradeInfo
    {
        public Tower.TowerType type;       //타입 지정  upgradeInfoDic의 Key값
        public Material typeTextColor;     //타입이름 텍스트 색상 변경용
        [NonSerialized]
        public int upgradeLevel=0;         //레벨
        [NonSerialized]
        public float nextUpgradeCost;      //다음 업그래이드 비용

        public Action noifyUpgraded;       //해당 타입의 타워들에게 알림
    }



    //레벨로 타워 목록을 검색하기 위한 Dic
    private Dictionary<int, Tower[]> towerDic = new Dictionary<int, Tower[]>();

    //레벨에 따른 타워목록
    [Serializable]
    public class TowerLevelList    //한 레벨의 타워 목록
    {
        [NonSerialized]
        public int level;                   //레벨(자동 설정)

        public string levelName;           //레벨명칭
        public Material levelColor;        //플랫폼 색상
        public Tower[] towerList;      //해당레벨의 타워 목록
    }
    

    #region UnityInspector 

    public float basicTowerCost = 100;     //1레벨 타워의 비용  
    public float firstUpgradeCost=2;
    public float increaseUpradeCost=2;
    public TypeUpgradeInfo[] typeUpgradeInfo;
    public TowerLevelList[] towerLevelList;   //레벨별 모든 타워목록 (인스펙터 뷰에서 편집)   

    #endregion UnityInspector
    

    //지어진 타워 목록
    private List<Tower> builtTowerList = new List<Tower>();
    

    //하이어라키 뷰에서 지어진 타워를 묶어놓기위한 오브젝트
    private GameObject towerHolder;
        

   

    //---(BuildManager의 다른 함수를 통해 실행)---

    //타워 사전에서 랜덤 타워 선정
    private Tower SelectRandomTower(int level)
    {
        //해당 레벨에 있는 모든 타워목록
        if (CheckLevel(level) == false)
        {            
            return null;
        }
        Tower[] randomTowerList = towerDic[level];
        //타워목록에서 랜덤으로 하나 선정
        int index = UnityEngine.Random.Range(0, randomTowerList.Length);
        //선정된 타워를 할당
        Tower selectedTower = randomTowerList[index];

        return selectedTower;
    }       
    
    //지어진 타워 목록에 지은 타워 추가
    private void AddBuiltTowerList(Tower builtTower)
    {
        builtTowerList.Add(builtTower);
    }

    //지어진 타워 목록에 대상 타워 제거
    private void RemoveBuiltTowerList(Tower builtTower)
    {
        builtTowerList.Remove(builtTower);
    }

    //해당 레벨에 타워가 있는지 검사
    private bool CheckLevel(int level)
    {
        bool checkLevel = false;
        if (towerDic.ContainsKey(level) == true)
        {
            checkLevel = true;
        }
        return checkLevel;
    }

    //해당 타워에 타워를 만들수 있는가 확인     MakeTower()를 실행하기전에 실행해서 확인
    private bool CanMakeTower(Tile targetTile, Tower targetTower)
    {
        bool canMake = false;
        if (targetTower == null)            //지을 타워가 없다면
        {
            return canMake;
        }
        if (targetTile.TowerBuilt == true)   //이미 타워가 지어져 있다면
        {
            return canMake;
        }
       
        canMake = true;  //만들수 있음을 확인
        return canMake;
    }

    //특정 레벨의 타워 만들기
    private void MakeTower(Tile targetTile, Tower targetTower)
    {
        
        Tower towerToBuild = targetTower;
        
        //타워 생성
        towerToBuild = (Tower)Instantiate(towerToBuild, targetTile.transform.position + targetTile.towerPositionOffset, targetTile.transform.rotation);
 
        //대상 타일의 타워가 지어진여부를 true로
        targetTile.TowerBuilt = true;
        //지어진 타워가 속한 타일 설정
        towerToBuild.UnderTile = targetTile;
        //업그레이드 이벤트에 데미지갱신함수 등록
        upgradeInfoDic[towerToBuild.towerType].noifyUpgraded +=()=>towerToBuild.SetDamage();
        //색상지정
        SetTowerColor(towerToBuild);
        //타워 리스트에 추가
        AddBuiltTowerList(towerToBuild);   
        
        //하이어라키 뷰에서 정리
        towerToBuild.transform.parent = towerHolder.transform;
    }

    //레벨에따른 타워 색깔 설정
    private void SetTowerColor(Tower targetTower)
    {       
        //타워의 레벨 수만큼 반복
        for (int i = 0; i<towerLevelList.Length; i++)
        {           
            //레벨이 같다면
            if (towerLevelList[i].level == targetTower.TowerLevel)
            {
                //색깔이 바뀌는 부분들에 대한 반복
                for (int j = 0; j < targetTower.colorPart.Length; j++)
                { 
                    //색상 적용
                    targetTower.colorPart[j].GetComponent<Renderer>().sharedMaterial = towerLevelList[i].levelColor;                   
                }               
            }
        }       
    }

    //타워 삭제
    private bool DeleteTower(Tower targetTower)
    {
        bool deleteSucceed = false;
        if (targetTower == null)
        {
            return false;
        }
        RemoveBuiltTowerList(targetTower);
        targetTower.UnderTile.TowerBuilt = false;
        Destroy(targetTower.gameObject);
        deleteSucceed = true;
        return deleteSucceed;
    }
    
    //업그래이드 하는데 필요한 가격을 가져오기
    public float GetUpgradeCost(Tower targetTower)
    {   
        //가격  =  첫 업그레이드 가격 + (업그레이드당 증가비용 * 업그레이드 레벨)
        float cost = firstUpgradeCost + (increaseUpradeCost * upgradeInfoDic[targetTower.towerType].upgradeLevel);
        upgradeInfoDic[targetTower.towerType].nextUpgradeCost = cost;
        return cost;
    }




      //------UI를 통해 플레이어가 직접 실행------
    #region UIMenuButton  

    //새타워 짓기
    public bool BuildNewTower(Tile targetTile)
    {
        bool buildSuceed = false;
        //충분한 돈이 없다면 return
        if(Player.SingleTon.Money < basicTowerCost==true)
        {
            return buildSuceed;
        }

        Tower targetTower = SelectRandomTower(1);      //랜덤타워 선택        
        buildSuceed = CanMakeTower(targetTile, targetTower); //타워를 만들수 있는가
        if (buildSuceed == false)
        {
            return buildSuceed;
        }
        Player.SingleTon.ChangeMoney(-basicTowerCost);       //돈 소모
        //타워 만들기
        MakeTower(targetTile, targetTower);
       
        return buildSuceed;
    }

    //타워 레벨업
    public bool LevelUpTower(Tower targetTower)
    {
        bool levelUpSuceed = false;          //성공 여부        
        int buildLevel = targetTower.TowerLevel + 1;   //지을 타워의 레벨

        Tower towerTobuild = SelectRandomTower(buildLevel);
        Tile targetTile = targetTower.UnderTile;
        //해당 레벨의 타워가 있는지 확인
        //해당 레벨이 존재하지 않는다면 return
        if (towerTobuild == null)
        {       
            return levelUpSuceed;
        }

        //지어진 타워 목록에서 같은 종류의 타워를 찾음
        foreach (Tower builtTower in builtTowerList)
        {
            //같은 종류의 타워를 찾음
            if (targetTower.towerId == builtTower.towerId)
            {
                //선택한 타워와 같은 타워라면 continue
                if (targetTower == builtTower)
                {
                    continue;
                }                
                
                //선택한 타워와 검색한 타워 삭제
                DeleteTower(targetTower);
                DeleteTower(builtTower);

                levelUpSuceed = CanMakeTower(targetTile, towerTobuild);  //타워를 만들수 있는지 확인
                if (levelUpSuceed == false)    //만들수 없다면 return
                {
                    return levelUpSuceed;
                }
                MakeTower(targetTile, towerTobuild); //타워 만들기   (성공시 upgradeSuceed =true)
                return levelUpSuceed;
            }
        }
        return levelUpSuceed;
    }

  
    //타워 업그래이드
    public void UpgradeTower(Tower targetTower)
    {
        float cost = GetUpgradeCost(targetTower);
        if(Player.SingleTon.Money < cost)
        {
            return;
        }
        //코스트 소비
        Player.SingleTon.ChangeMoney(-cost);
        //레벨증가
        upgradeInfoDic[targetTower.towerType].upgradeLevel++;      

        //업그래이드됬음을 해당 타입의 타워들에게 알림
        if (upgradeInfoDic[targetTower.towerType].noifyUpgraded!= null)
        {
            upgradeInfoDic[targetTower.towerType].noifyUpgraded();
        }     
        
    }

    //타워 되팔기
    public bool SellTower(Tower targetTower)
    {
        bool deleteSucceed = false;
        deleteSucceed = DeleteTower(targetTower);
        if(deleteSucceed == false)
        {
            return deleteSucceed;
        }        
        Player.SingleTon.ChangeMoney(targetTower.sellCost);
        deleteSucceed = true;
        return deleteSucceed;
    }    
    
    //특정 타워 짓기
    public bool BuildSpecificTower(Tower targetTower)
    {
        bool buildSuceed = false;
        if (Player.SingleTon.SpecialPoint <= 0)
            return buildSuceed;
        Tile targetTile;
        //TileMenuUI가 활성화 상태인지 확인
        if(TileMenuUI.SingleTon.gameObject.activeSelf == false)
        {
            return buildSuceed;
        }
        //TileMenuUI의 타겟 Tile에 타워가 지어져 있는가
        targetTile = TileMenuUI.SingleTon.TargetTile;
        if (targetTile.TowerBuilt == true)
        {
            return buildSuceed;
        }
        

        buildSuceed = CanMakeTower(targetTile, targetTower);    //타워를 만들수 있는지 확인
        if (buildSuceed == false)
        {
            return buildSuceed;
        }
        Player.SingleTon.SpecialPoint--;
        MakeTower(targetTile, targetTower);    //타워 만들기
        return buildSuceed;
      
    }

    #endregion UIMenuButton  


      

    //싱글톤
    public static BuildManager SingleTon = null;
    //==========Awake()=========
    void Awake()
    {
        if (SingleTon)
        {
            Destroy(this.gameObject);
            return;
        }
        SingleTon = this;
        MakeTypeUpgradeDictoinary();
        MakeTowerLevelDictionary();
        SetTowerLevel();
        if (towerHolder == null)
        {
            towerHolder = new GameObject();
            towerHolder.name = "TowerHolder";
        }
    }


    //타입을 키값으로 가지고 키에 따른 업그래이드 정보(색상, 단계등등)를 사전에 추가
    public void MakeTypeUpgradeDictoinary()
    {       
        for(int i=0; i<typeUpgradeInfo.Length; i++)
        {
            if(upgradeInfoDic.ContainsKey(typeUpgradeInfo[i].type) == false)
            {
                upgradeInfoDic.Add(typeUpgradeInfo[i].type, typeUpgradeInfo[i]);
                typeUpgradeInfo[i].nextUpgradeCost = firstUpgradeCost;
            }            
        }
    }


    //인스펙터뷰에서 편집한 레벨을 키값으로 하고 그에 따른 타워목록을 사전에 추가
    public void MakeTowerLevelDictionary()
    {
        for (int i = 0; i < towerLevelList.Length; i++)
        {
            towerLevelList[i].level = i + 1; //레벨 설정
            if (towerDic.ContainsKey(towerLevelList[i].level) == false){
                towerDic.Add(towerLevelList[i].level, towerLevelList[i].towerList);
            }            
        }
    }
    
    
    //인스펙터에 타워 목록을 편집한 곳에서 게임시작후 레벨정보를 받아 각 타워의 Towelevel에 적용
    public void SetTowerLevel()
    {
        //모든 레벨에대해 반복
        for (int i = 0; i < towerLevelList.Length; i++)
        {
            //각 레벨의 타워리스트의 개수 만큼 반복
            for (int j = 0; j < towerLevelList[i].towerList.Length; j++)
            {
                //towerLevelList에 지정된 레벨을 각타워의 레벨에 적용
                towerLevelList[i].towerList[j].TowerLevel = towerLevelList[i].level;
            }
        }
    }


   
}
