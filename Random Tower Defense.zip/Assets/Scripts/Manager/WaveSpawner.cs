﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using System;
using System.Xml;


public class WaveSpawner : MonoBehaviour
{
    public TextAsset enemyData;                    //enemy에 대한 정보가 있는 TextAsset    
          
    private XmlDocument enemyDataXml;              //TextAsset를 XmlDocument로 바꾼 것을 담을 변수
    XmlElement allEnemyDataXml;

    #region UnityInpector

    public Transform spawnPoint;         //생성되는 위치
    public float firstWaveTime = 20f;     //게임시작후 첫웨이브까지 준비시간
    public float timeBetweenWaves = 5f;    //웨이브 사이의 준비시간
    public float timeBetweemSpawn= 0.5f;       //스폰 간격
    public int waveReward = 200;            //하나의 웨이브를 클리어시 보상

    #endregion UnityInpector


    [NonSerialized]
    public float countDown;                          //카운트다운
    [NonSerialized]
    public int remainEnemy = 0;                    //한 웨이브에서 남은 적들
    [NonSerialized]
    public int currentWaveNumber = 0;                //현재 진행중인 웨이브
    private bool wavePlaying = false;              //웨이브가 진행중인지 여부
    public bool WavePlaying
    {
        get
        {
            return wavePlaying;
        }
    }
    private bool bonusPlaying = false;
    public bool BonusPlaying
    {
        get
        {
            return bonusPlaying;
        }
    }


    private Coroutine startCountdownCouroutin;    //카운트다운 코루틴제어용
    
            
    [Serializable]
    public class Wave
    {
        public int waveNumber;                      //웨이브 넘버
        public string Memo;            
        public Enemy enemyPrefab;                   //생성시킬 적
        [Header("XML Automatic Setting Field")]     //xml를 통해 자동으로 설정됨
        public float enemyHealth;                   //체력
        public float enemySpeed;                    //스피드
        public float enemyDamage;                   //데미지
        public int spawnCount;                      //생성할 수 
    }


    public List<Wave> waveList;                   //인스펙터뷰에서 웨이브 편집
        

    //초 세기
    public event Action startCountDown;             //카운트다운 시작시
    public event Action changeCountDown;            //CountDown바뀔때     
    public event Action hideCountDown;              //시간이 모두 끝났을때
    IEnumerator StartCountDown()
    {    
        countDown = timeBetweenWaves;      //카운트다운 초기화
        if (startCountDown != null)
        {
            startCountDown();
        }
        //초세기
        while (countDown > 0)
        {
            countDown -= Time.deltaTime;
            countDown = Mathf.Clamp(countDown, 0f, Mathf.Infinity);
            if (changeCountDown != null)
            {
                changeCountDown();
            }
            yield return null;
        }
        if (hideCountDown != null)
        {
            hideCountDown();
        }
        
        StartCoroutine(StartWave());
        wavePlaying = true;
    }




    //Xml을 통해
    //적의 체력, 스피드, 스폰되는 수, 데미지(프리팹은 제외)을 추가   
    public void SetWaveByXml()
    {
        //waveList 클리어
        //waveList.Clear();
        //xml파일 로드
        enemyDataXml = new XmlDocument();
        enemyDataXml.LoadXml(enemyData.text);

        //모든 xml정보
        allEnemyDataXml = enemyDataXml["EnemyStatList"];


        //xml의 모든 자식노드만큼 반복
        int i = 0;
        foreach (XmlElement targetEnemyNode in allEnemyDataXml.ChildNodes)
        {    
            //waveList의 Index를 벗어나면
            if (waveList.Count <= i)
               return;
            //waveList의 필드에 데이터 적용
            waveList[i].waveNumber = int.Parse(targetEnemyNode.GetAttribute("WaveNumber"));
            waveList[i].enemyHealth = float.Parse(targetEnemyNode.SelectSingleNode("Health").InnerText);
            waveList[i].enemySpeed = float.Parse(targetEnemyNode.SelectSingleNode("Speed").InnerText);           
            waveList[i].enemyDamage = float.Parse(targetEnemyNode.SelectSingleNode("Damage").InnerText);
            waveList[i].spawnCount = int.Parse(targetEnemyNode.SelectSingleNode("SpawnNumber").InnerText);
            i++;
        }


    }


    //적 능력치 적용
    void SetEnemyState(Wave targetWave , Enemy enemy)
    {
        enemy.MaxHealth = targetWave.enemyHealth;      
        enemy.Speed = targetWave.enemySpeed;    
        enemy.Damage = targetWave.enemyDamage;       
    }


    //웨이브 시작하기
    public event Action startWave;    
    IEnumerator StartWave()
    {
        currentWaveNumber++;               //현재웨이브+1
        int waveIndex = currentWaveNumber-1;
        wavePlaying = true;
        remainEnemy = waveList[waveIndex].spawnCount;
               
        if (startWave != null)
        {
            startWave();
        }  

        //적생성
        for (int i = 0; i < waveList[waveIndex].spawnCount; i++)
        {
            SpawnEnemy(waveList[waveIndex].enemyPrefab);
            yield return new WaitForSeconds(timeBetweemSpawn);
        }  
    }
        

    //적 만들기
    private void SpawnEnemy(Enemy target)
    {
       // Enemy spawnedEnemy = (Enemy) Instantiate(target, spawnPoint.position, spawnPoint.rotation);
        GameObject madeObject = ObjectPoolingManager.SingleTon.ActiveGameObject(target.gameObject, spawnPoint.transform);
        if (madeObject != null)
        {
            Enemy spawnedEnemy = madeObject.GetComponent<Enemy>();         
            //능력치 설정
            SetEnemyState(waveList[currentWaveNumber - 1], spawnedEnemy);
            spawnedEnemy.SetHPFull();
            //이벤트 설정
            spawnedEnemy.whenEnemyDisappear += () => WhenEnemyDisappear(spawnedEnemy);
        }        
    }


    //적 모두 처치시 웨이브 끝
    public event Action endWave;
    void EndWave()
    {
        if (endWave != null)
        {
            endWave();
        }
      
        wavePlaying = false;
        Reward(waveReward);            //플레이어에게 보상 지급
        //인덱스를 체크하여 다음 웨이브가 없거나
        //다음 웨이브에 적의 프리팹이 할당 되어 있지 않다면 Clear
        if(currentWaveNumber >= waveList.Count||waveList[currentWaveNumber].enemyPrefab==null)
        {
            GameClear();
            return;
        }
        if(this != null)
        {
            startCountdownCouroutin = StartCoroutine(StartCountDown());  //카운트 다운 시작
        }
        
    }


    //스폰한 적이 사라졌을때 실행할 함수&이벤트
    public event Action whenEnemyDisappear;   
    void WhenEnemyDisappear(Enemy spawnedEnemy)
    {
        remainEnemy--;   //남은적 -1        
        if (whenEnemyDisappear != null)
        {
            whenEnemyDisappear();
        }
        if (remainEnemy == 0)
        {
            EndWave();
        }
    }
    

    //웨이브 끝난후 보상 지급
    void Reward(int amount)
    {
        Player.SingleTon.ChangeMoney(amount);
    }


    //보너스적 스폰
    public void SpawnBonusEnemy(BonusEnemy bonusEnemy)
    {
        //웨이브가 진핼중일시 return
        if (wavePlaying == true|| bonusPlaying ==true)
        {
            return;
        }        
        //카운트다운 코루틴 중단
        StopCoroutine(startCountdownCouroutin);
        hideCountDown();

        //에너미 스폰
        BonusEnemy spawnedEnemy = (BonusEnemy)Instantiate(bonusEnemy, spawnPoint.position, spawnPoint.rotation);

        bonusPlaying = true;
        //스폰된 적이 사라졌을때 카운트 다운 다시 시작        
        spawnedEnemy.whenEnemyDisappear += () => startCountdownCouroutin = StartCoroutine(StartCountDown());
        spawnedEnemy.whenEnemyDisappear += () => bonusPlaying = false;
    }


    //게임 클리어
    public void GameClear()
    {
        GameManager.SingleTon.WhenGameClear();
    }


    //싱글톤
    public static WaveSpawner SingleTon = null;



    //타임라인
    //============Awake()==========
    void Awake()
    {
        if (SingleTon)
        {
            Destroy(this.gameObject);
            return;
        }
        SingleTon = this;        
    }


    //============Start()==========
    void Start()
    {
        //첫웨이브 시작시간 설정
        countDown = firstWaveTime;
        //카운트다운 시작
        startCountdownCouroutin = StartCoroutine(StartCountDown());    
    }
      
      
}

