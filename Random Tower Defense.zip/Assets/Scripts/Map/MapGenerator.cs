﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Xml;


public class MapGenerator : MonoBehaviour {

    public TextAsset mapData;                    //맵에 대한 정보가 있는 TextAsset   
           
    private XmlDocument mapDataXml;                  //TextAsset를 XmlDocument로 바꾼 것을 담을 변수
    private XmlElement allMapXml;
    

    public Tile tilePrefab;                       //생성시킬 타일
    
    [Range(0.1f, 5)]
    public float tileSize = 1;            //타일 크기
    public string mapName = "1";           //맵의 이름으로 Xml의 특정 맵코드를 찾음

    [TextArea(10,20)]
    public string mapCode;              //전체 맵 (oneRowOfMap의 배열)

    


    //xml에서 얻은 문자열을 통해 맵을 생성하는 함수
    //인스펙터 뷰에서 버튼으로 실행
    public void GenerateMapByXml()
    {
        //생성되어 있는 맵을 검색하여 있다면 삭제후 다시 생성
        GameObject generatedMap = GameObject.Find("GeneratedMap");
        if (generatedMap != null)
        {
            DestroyImmediate(generatedMap);
        }

        //xml파일 로드
        mapDataXml = new XmlDocument();
        mapDataXml.LoadXml(mapData.text);

        //모든 xml정보
        allMapXml = mapDataXml["MapList"];

        foreach (XmlElement targetMapNode in allMapXml.ChildNodes)
        {
            //각노드의 "Name"값이 외부에서 입력한 이름과 같다면
            if (targetMapNode.GetAttribute("Name") == mapName)
            {
                //MapCode하는 하위 노드의 텍스트를 얻어 mapCode 에 입력
                mapCode = targetMapNode.SelectSingleNode("MapCode").InnerText;
                break;
            }
        }
        
        
        //홀더 생성
        generatedMap = new GameObject();
        generatedMap.name="GeneratedMap";

        //타일의 위치 (첫타일 위치 (0,0,0)에서 xml처음 줄바꿈을 고려해서 (0,0,1))
        Vector3 tilePosition = new Vector3(0,0,1); 
        //xml에서 얻은 mapCode의 텍스트로 타일 생성
        for (int i=0; i<mapCode.Length; i++)
        {          
            Tile madeTile;
            char code = mapCode[i];     

            switch (code)
            {
                //PathTile생성
                case ('|') :
                    //타일 생성                 
                    madeTile= (Tile)Instantiate(tilePrefab, tilePosition, Quaternion.identity);
                    //크기조절
                    madeTile.transform.localScale = new Vector3(tileSize * 0.1f, 1, tileSize * 0.1f);
                    //타일타입을 설정하고 타일타입에 따른 메테리얼 설정          
                    madeTile.SetTiletypeAndMaterial(Tile.TileType.PATH);
                    //GeneratedMap의 자식으로 만듬
                    madeTile.transform.parent = generatedMap.transform;
                    //다음에 생성될 타입의 위치 설정
                    tilePosition.x = tilePosition.x + tileSize;                    
                    break;

                //BuildTile생성  //아래구문은 TileType만 제외하고 같음
                case ('#'):
                    madeTile = (Tile)Instantiate(tilePrefab, tilePosition, Quaternion.identity);
                    madeTile.transform.localScale = new Vector3(tileSize * 0.1f, 1, tileSize* 0.1f);                      
                    madeTile.SetTiletypeAndMaterial(Tile.TileType.EMPTY);
                    madeTile.transform.parent = generatedMap.transform;
                    tilePosition.x = tilePosition.x + tileSize;
                    break;

                //공백일때는 생성 하지 않고 다음 위치로
                case (' '):                  
                    tilePosition.x = tilePosition.x + tileSize;
                    break;

                //줄바꿈일때 생성하지 않고 다음줄로 넘어감
                case ('\n'):
                    //다음 타일의 위치를 x값은 초기화하고 z값은 내림
                    tilePosition.z = tilePosition.z - tileSize;
                    tilePosition.x = 0;
                    break;

                default:
                    break;
                    
            }
                
        }

    }
}
