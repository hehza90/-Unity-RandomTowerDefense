﻿using UnityEngine;
using System.Collections;
using UnityEngine.EventSystems;
using System;
using System.Collections.Generic;

public class Tile : MonoBehaviour
{
    public Renderer thisRenderer;
    public Material originalMaterial;         //본레의 메테리얼

    public Vector3 towerPositionOffset = new Vector3();

    #region UnityInspector
    [Header("Materials")]
    public Material emptyMaterial;        //빌드타일의 메테리얼
    public Material pathMaterial;         //길의 메테리얼    
    public Material onMouseMaterial;      //마우스가 위에 있을때
    public Material normalMaterial;

    #endregion UnityInspector

    //이 타일에 타워가 지어졌는지 여부
    private bool towerBuilt = false;   
    public bool TowerBuilt
    {
        get
        {
            return towerBuilt;
        }
        set
        {
            towerBuilt = value;
        }
    }               //towerBuilt 프로퍼티


    public enum TileType
    {
        NORMAL, EMPTY, PATH
    }

    public TileType tileType = TileType.NORMAL;

    //type 프로퍼티
    public TileType tileTypeProperty
    {
        get
        {
            return tileType;
        }
        set
        {
            tileType = value;
        }
    }


    //(유니티에디터에서)MapGenerator에서 실행
    public void SetOriginalMaterial()
    {
        thisRenderer = this.GetComponent<Renderer>();
        
        switch (tileType)
        {
            case (TileType.EMPTY):
                thisRenderer.material = emptyMaterial;               
                break;
            case (TileType.PATH):
                thisRenderer.sharedMaterial = pathMaterial;               
                break;
            case (TileType.NORMAL):
                thisRenderer.sharedMaterial = normalMaterial;              
                break;
            default:
                break;
        }
        originalMaterial = thisRenderer.sharedMaterial;

    }
    
    public void SetTiletypeAndMaterial(TileType _tileType)
    {
        tileType = _tileType;
        thisRenderer = this.GetComponent<Renderer>();

        switch (tileType)
        {
            case (TileType.EMPTY):
                thisRenderer.material = emptyMaterial;
                break;
            case (TileType.PATH):
                thisRenderer.sharedMaterial = pathMaterial;
                break;
            case (TileType.NORMAL):
                thisRenderer.sharedMaterial = normalMaterial;
                break;
            default:
                break;
        }
        originalMaterial = thisRenderer.sharedMaterial;
    }    
   
    void Start()
    {

    }

    //-----마우스&터치 조작----
    //마우스가 위에있을떄
    void OnMouseEnter()
    {         
        //클릭하는 곳에 EventSystem의 오브젝트( UI)가 있다면 무시
        if (EventSystem.current.IsPointerOverGameObject() == true)
        {
            return;
        }

        if (tileType != TileType.EMPTY)
        {
            return;
        }

        thisRenderer.material = onMouseMaterial;

    }
    //마우스가 나갔을때
    void OnMouseExit()
    {
        if (tileType != TileType.EMPTY)
        {
            return;
        }
        thisRenderer.material = originalMaterial;
    }
    //클릭&터치시

    //클릭되었을때 실행될 이벤트
    delegate void ClickDeligate (Tile thisTile);
    void OnMouseDown()
    {
        //위에 상호작용 하는 UI요소가 있는지 확인
        if (Utility.IsPointerOverUIObject() == true)
        {
            return;
        }
    
        if (tileType != TileType.EMPTY || TowerBuilt == true)
        {
            //기존의 열려있는 메뉴를 닫음
            TileMenuUI.SingleTon.Close();
            TowerMenuUI.SingleTon.Close();
            return;
        }
        //메뉴 호출 및 대상 설정               
        TileMenuUI.SingleTon.SetTargetTile(this);
    }

}
