﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

//모든 웨이포인트을 자식으로 가지며 웨이포인트들의 배열을 제공
public class Waypoints : MonoBehaviour {

   
    public List<Transform> wayPoinList = new List<Transform>(); //웨이포인트 리스트
   
    public static Waypoints SingleTon = null;  //싱글톤


    //============Awake()===========
    void Awake()
    {    
        if (SingleTon)
        {
            Destroy(this.gameObject);
            return;
        }
        SingleTon = this;        
    }

    //============Start()===========
    void Start()
    {
        //points = new Transform[this.transform.childCount];
        for (int i = 0; i < this.transform.childCount; i++)
        {
            wayPoinList.Add(this.transform.GetChild(i));
        }
    }

}
