﻿using UnityEngine;
using System.Collections;
using System;

public class Player : MonoBehaviour {
        
    //현제 Lives
    private float lives;
    //현재 Money
    private float money;
    //현재 Sp
    private float specialPoint;

    #region UnityInspector

    //시작 Lives
    public float startLives;
    //시작 Money
    public float startMoney;
    //시작 SP
    public float startSpecialPoint;

    #endregion UnityInspector
    

    //---프로퍼티
    public float Money
    {
        get
        {
            return money;
        }
        set
        {
            money = value;          
        }
    }

    public float Lives
    {
        get
        {
            return lives;
        }
        set
        {
            lives = value;
           // InformationUI.SingleTon.RenewLivesUI();
        }
    }

    public float SpecialPoint
    {
        get
        {
            return specialPoint;
        }
        set
        {
            specialPoint = value;
        }
    }


    public static Player SingleTon = null;
    //============Awake()===============
    void Awake()
    {
        if (SingleTon)
        {
            Destroy(this.gameObject);
            return;
        }
        SingleTon = this;

        money = startMoney;
        lives = startLives;
        SpecialPoint = startSpecialPoint;
    }



    //Lives가 바뀔때 실행 할 이벤트
    public event Action changeLive;
    //Lives를 변동시키는 함수
    public void ChangeLives(float amount)
    {
        ////게임오버시 return
        //if (GameManager.SingleTon.GameOver == true)
        //{
        //    return;
        //}
        lives += amount;   //변동적용
        //이벤트 실행
        if (changeLive != null)
        {
            changeLive();
        }
        //0이하일시 Die
        if(GameManager.SingleTon.GameOver ==false && lives <= 0) {
            PlayerDie();
        }       
    }


    //Money가 바뀔때 실행 할 이벤트
    public event Action changeMoney;
    //Money를 변동시키는 함수
    public bool ChangeMoney(float amount)
    {        
        bool enoughMoney = false;   //충분한 Money가 있는가
        //돈이 감소 할때
        if (amount < 0)
        {
            enoughMoney = money >= -amount;
            if(enoughMoney == false)
            {
                return enoughMoney;
            }            
        }
        enoughMoney = true;
        money += amount;
        //이벤트 실행
        if (changeMoney != null)
        {
            changeMoney();
        }
        return enoughMoney;
    }
    

    //SpecialPoint가 바뀔때 실행 할 이벤트
    public event Action changeSpecialPoint;
    //SpecialPoint를 변동시키는 함수
    public bool ChangeSpecialPoint(float amount)
    {
        bool enoughSpecialPoint = false;   //충분한 Money가 있는가
        //돈이 감소 할때
        if (amount < 0)
        {
            enoughSpecialPoint = specialPoint >= -amount;
            if (enoughSpecialPoint == false)
            {
                return enoughSpecialPoint;
            }
        }
        enoughSpecialPoint = true;
        specialPoint += amount;
        //이벤트 실행
        if (changeSpecialPoint != null)
        {
            changeSpecialPoint();
        }
        return enoughSpecialPoint;
    }


    public void PlayerDie()
    {
        GameManager.SingleTon.WhenPlayerDie();
    }

}
