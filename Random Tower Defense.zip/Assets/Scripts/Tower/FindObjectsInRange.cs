﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FindObjectsInRange : MonoBehaviour {

    public Tower thisTower;    
   
    
    void Awake()
    {
        thisTower = this.gameObject.GetComponentInParent<Tower>();
        thisTower.targetLayer = LayerMask.NameToLayer("Enemy");
    }

    
    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.layer == thisTower.targetLayer.value)
        {
            //현제 설정되어 있는 타겟이 없다면 해당 프레임에 충돌한 객체를 타겟으로 설정
            if (thisTower.targetEnemy == null)
            {
                thisTower.SetTarget();
            }         
            thisTower.enemysInRange.Add(other.gameObject);
        }
    }

    void OnTriggerExit(Collider other)
    {
        if (other.gameObject.layer == thisTower.targetLayer)
        {
            //타겟이 지정되어 있다면 현제 타겟되어있는 객체와 같은 객체인지 확인
            //같다면 타겟 해제후 다시 SetTarget();
            if (thisTower.targetEnemy != null)
            {
                if (thisTower.targetEnemy.gameObject == other.gameObject)
                {
                    thisTower.targetEnemy = null;                   
                }
                thisTower.enemysInRange.Remove(other.gameObject);
               
            }            
        }        
    }


}