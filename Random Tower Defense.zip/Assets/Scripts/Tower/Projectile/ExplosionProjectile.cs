﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ExplosionProjectile : Projectile {

    public float explosionRadius;



    protected override void AffectTarget()
    {
        Explode();
    }




    void Explode()
    {
        
        Collider[] colliders = Physics.OverlapSphere(transform.position, explosionRadius);

        foreach (Collider collider in colliders)
        {           
            GameObject target = collider.gameObject;
            IDamageable damegeable = target.GetComponent<IDamageable>();  //데미지를 줄수 있는 대상인지 검사
            if (damegeable != null)
            {
                if (target != null && target.activeSelf == true)
                Damage(target);
            }                     
        }

    }


    //씬뷰에서 선택시 폭발 범위 그리기
    void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(this.transform.position, explosionRadius);
    }
}
