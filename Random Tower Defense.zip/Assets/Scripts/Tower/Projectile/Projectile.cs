﻿using UnityEngine;
using System.Collections;

public class Projectile : MonoBehaviour {

    public GameObject model;           //발사시 눈에 보이는 모델
    public GameObject explosionEffect; //적중시 눈에 보이는 이펙트


    public float speed = 70f;
    public float damage;

    public bool hit = false;
    public GameObject target;
    public Vector3 targetPosition;
    private Vector3 moveDirection;
    

    public void SetTarget(GameObject _target)
    {
        target = _target;
    }

    private void OnEnable()
    {
        explosionEffect.SetActive(false);   //이펙트 끄기
        model.SetActive(true);              //모델 켜기
        hit = false;
    }

	private void Update()
    {      
        if (hit == true)
        {
            return;
        }
        //방향결정
        moveDirection = targetPosition - this.transform.position;
       
        //타겟이 없다면 앞으로
        if (target == null||target.gameObject.activeSelf==false)
        {          
            //목적지에 이르었다면
            if ((targetPosition - this.transform.position).magnitude <= 0.2f )
            {
                HitTarget();
            }                      
        }

        else
        {
            //타겟의 위치를 받아옴
            targetPosition = target.transform.position;            
            this.transform.LookAt(targetPosition);           
           //타겟과 충분히 가까워 지면             
            if (moveDirection.magnitude <= 0.5f)
            {              
                HitTarget();                
            }
        }
   
        //이동
        transform.Translate(moveDirection.normalized * speed * Time.deltaTime, Space.World);
        
        //점점 빨라지게
        speed += 0.1f;
    }
        
    //목표지점에 도착했을때
    private void HitTarget()
    {
       
        AffectTarget();
        explosionEffect.SetActive(true);    //이펙트 켜기
        model.SetActive(false);             //모델 끄기
        Invoke("Deactive", 2f);
        hit = true;
    }

    //비활성화 시키기
    void Deactive()
    {
        ObjectPoolingManager.SingleTon.DestroyOrDisable(this.gameObject);   //사라짐
    }

    //타겟에 영향을 미칠때 어떤 행동을 할것인가
    protected virtual void AffectTarget()
    {
        //타겟이 있다면 데미지를 줌
        if (target != null && target.activeSelf == true)
        {
            Damage(target);
        }
    }
    
    //데미지 주기
    protected void Damage(GameObject target)
    {
        //데미지를 줄수 있는 대상인지 검사
        IDamageable damegeable = target.GetComponent<IDamageable>();  
        if (damegeable != null)
        {
            damegeable.TakeDamage(this.damage);          
        }
    }
}
