﻿using UnityEngine;
using System.Collections;

public class BonusEnemyMenuUI : UI {

    public static BonusEnemyMenuUI SingleTon = null;
    //==========Awake()============
    void Awake()
    {        
        if (SingleTon)
        {
            Destroy(this.gameObject);
            return;
        }
        SingleTon = this;
        Close();
    }

}
