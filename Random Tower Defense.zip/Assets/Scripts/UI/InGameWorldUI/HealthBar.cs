﻿using UnityEngine;
using UnityEngine.UI;

public class HealthBar : MonoBehaviour {


    public Life target;   //체력을 표시할 대상
    public Image healthImage;             //HP을 나타내는 초록색바
    public Material fullHP;        //HP가 많을때
    public Material middleHP;      //HP가 중간정도
    public Material lowHP;         //HP가 적을때

    private Vector3 healthBarOffset;    //대상과 HP바가 떨어져 있는 위치
    private Quaternion healthBarRotation;   //HP바가 유지할 회전 값

    

    void Awake()
    {
        //HP바를 고정시킬 회전과 위치값
        healthBarRotation = this.transform.rotation;
        healthBarOffset = this.transform.position - target.transform.position;
        //타겟이 데미지를 받을때 이벤트 등록
        target.changeHP += () => SetHealthImage();
    }

    
    void Update () {
        //HP바의 위치와 회전 값 고정
        this.transform.rotation = healthBarRotation;
        this.transform.position = target.transform.position + healthBarOffset;
    }

    //HP갱신 타겟의 HP가 변할때만 실행
    //HP의 양에 따라 색상 변경
    void SetHealthImage()
    {
        healthImage.fillAmount = target.Currenthealth / target.MaxHealth;

        if (healthImage.fillAmount >= 0.6f)
        {
            healthImage.color = fullHP.color;
        }
        else if(healthImage.fillAmount > 0.2f && healthImage.fillAmount < 0.6f)
        {      
            healthImage.color = middleHP.color;
        }

        else if (healthImage.fillAmount <= 0.2f)
        {
            healthImage.color = lowHP.color;
        }

    }

}

