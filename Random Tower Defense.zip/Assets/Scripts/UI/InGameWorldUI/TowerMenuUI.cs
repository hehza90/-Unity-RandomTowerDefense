﻿using UnityEngine;
using UnityEngine.UI;

public class TowerMenuUI : UI {

    #region UnityInspector
       
    public Text nameText;
    public Text upgradeLevelText;
    public Text upgradeCostText;
    public Text levelUpText;
    public Text sellCostButtonText;

    #endregion UnityInspector 


    public Vector3 offset = new Vector3(0, 0.5f, 0); //UI가 타겟으로부터 떨어져있는정도
    private Tower targetTower;      //대상 타일
    public Tower TargetTower        //프로퍼티, 외부에서는 읽기 전용
    {
        get
        {
            return targetTower;
        }
        private set
        {
            targetTower = value;
        }
    }


    public static TowerMenuUI SingleTon = null;


    //UI열기
    public override void Open()
    {
        base.Open();
        TileMenuUI.SingleTon.Close();

    }
    

    //타겟 타워 설정 타워 클릭시 실행
    public void SetTargetTower(Tower target)
    {
        Open();
        TargetTower = target;
        this.transform.position = TargetTower.transform.position + offset;
        
        //타워이름 및 타입에 대한 색상 적용
        nameText.text = targetTower.towerName;
        nameText.color = BuildManager.SingleTon.upgradeInfoDic[targetTower.towerType].typeTextColor.color;
        //타겟타워가 최종 레벨 일 경우
        if (targetTower.TowerLevel>=  BuildManager.SingleTon.towerLevelList.Length)
        {
            levelUpText.color = Color.gray;
        }
        else
        {
            levelUpText.color = BuildManager.SingleTon.towerLevelList[targetTower.TowerLevel].levelColor.color;
        }
        
            //upgradeInfoDic[targetTower.towerType].typeTextColor.color;
        //대상 타워의 판매가격에 따른 텍스트 변경
        sellCostButtonText.text = "+" + targetTower.sellCost.ToString() + "$";

        RenewUpgradeCost();
    }

    //업그래이드 가격&레벨 정보 갱신
    public void RenewUpgradeCost()
    {        
        upgradeCostText.text = "-" + BuildManager.SingleTon.GetUpgradeCost(targetTower).ToString() + "$";
        upgradeLevelText.text = "LV " + BuildManager.SingleTon.upgradeInfoDic[targetTower.towerType].upgradeLevel.ToString();        
    }

    

    #region ButtonMenu      
    //레벨업
    public void LevelUp()
    {       
        bool levelUpSuceed = false;
        levelUpSuceed = BuildManager.SingleTon.LevelUpTower(targetTower);
        //성공시 닫음
        if(levelUpSuceed == true)
        {
            Close();
        }       
    }    

    //되팔기
    public void Sell()
    {
        bool sellSucced = false;
        sellSucced = BuildManager.SingleTon.SellTower(targetTower);
        if(sellSucced == true)
        {
            Close();
        }        
    }
    
    //업그레이드
    public void Upgrade()
    {
        BuildManager.SingleTon.UpgradeTower(targetTower);
        RenewUpgradeCost();

    }

    #endregion ButtonMenu      




    //==========Awake()============
    void Awake()
    {
        if (SingleTon)
        {
            Destroy(this.gameObject);
            return;
        }
        SingleTon = this;
        Close();
    }
    


}
