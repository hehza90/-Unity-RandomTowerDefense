﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;


public class InformationUI : MonoBehaviour {

    #region UnityInspector 

    [Header("Wave Info")]
    public Text waveIndexTextUI;
    public Text enemyRemainTextUI;
    [Header("Count Down")]
    public Text countDownText; //카운트다운 텍스트
    [Header("Player Info")]
    public Text livesTextUI;     //남은 생명
    public Text moneyTextUI;     //남은 돈
    public Text specialPointTextUI;  //남은 SP
    
    #endregion UnityInspector 


    public static InformationUI SingleTon = null;
    //============Awake()===============
    void Awake()
    {
        if (SingleTon)
        {
            Destroy(this.gameObject);
            return;
        }
        SingleTon = this;
       
        //관심있는 정보에 이벤트 등록

        //플레이어 Lives&Money
        Player.SingleTon.changeLive += () => Renew(livesTextUI, Player.SingleTon.Lives.ToString());
        Player.SingleTon.changeMoney += () => Renew(moneyTextUI, Player.SingleTon.Money.ToString());
        Player.SingleTon.changeSpecialPoint += () => Renew(specialPointTextUI, Player.SingleTon.SpecialPoint.ToString());
        //웨이브&적정보
        WaveSpawner.SingleTon.startWave += () => Renew(waveIndexTextUI, WaveSpawner.SingleTon.currentWaveNumber.ToString());
        WaveSpawner.SingleTon.startWave += () => Renew(enemyRemainTextUI, WaveSpawner.SingleTon.remainEnemy.ToString());
        WaveSpawner.SingleTon.whenEnemyDisappear += () => Renew(enemyRemainTextUI, WaveSpawner.SingleTon.remainEnemy.ToString());
        //카운트 다운
        WaveSpawner.SingleTon.startCountDown += () => OpenUI(countDownText);
        WaveSpawner.SingleTon.changeCountDown += () => Renew(countDownText, string.Format("{0:00.00}", WaveSpawner.SingleTon.countDown));
        WaveSpawner.SingleTon.hideCountDown += () => CloseUI(countDownText);       
    }

    void Start()
    {
        //게임 시작시 한번씩 갱신
        Renew(livesTextUI, Player.SingleTon.Lives.ToString());
        Renew(moneyTextUI, Player.SingleTon.Money.ToString());
        Renew(specialPointTextUI, Player.SingleTon.SpecialPoint.ToString());
        Renew(waveIndexTextUI, WaveSpawner.SingleTon.currentWaveNumber.ToString());
        Renew(enemyRemainTextUI, WaveSpawner.SingleTon.remainEnemy.ToString());
      
    }
 
        
    //UI의 정보 갱신
    public void Renew(Text targetUI, string information)
    {
        if(targetUI!=null)
            targetUI.text = information;
    }
  
    //특정UI열기
    public void OpenUI(Text targetUI)
    {
        if(targetUI != null)
        targetUI.enabled = true;
    }
    //특정UI닫기
    public void CloseUI(Text targetUI)
    {
       if(targetUI != null)
        targetUI.enabled = false;
    }
}
