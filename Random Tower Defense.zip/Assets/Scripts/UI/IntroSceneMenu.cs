﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class IntroSceneMenu : MonoBehaviour {


    public void StartButton()
    {
        SceneManager.LoadScene("StandardMap", LoadSceneMode.Single);
    }

}
