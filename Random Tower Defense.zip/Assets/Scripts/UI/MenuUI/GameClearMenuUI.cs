﻿using UnityEngine.SceneManagement;
using UnityEngine;

public class GameClearMenuUI : MonoBehaviour {

    public void MainMenuButton()
    {
        SceneManager.LoadScene("MainMenu", LoadSceneMode.Single);
    }
}
