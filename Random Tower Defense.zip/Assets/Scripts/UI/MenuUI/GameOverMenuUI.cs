﻿using UnityEngine.SceneManagement;
using UnityEngine;

public class GameOverMenuUI : MonoBehaviour {
    
    public void RestartButton()
    {
        SceneManager.LoadScene("StandardMap", LoadSceneMode.Single);
    }

    public void MainMenuButton()
    {
        SceneManager.LoadScene("MainMenu", LoadSceneMode.Single);
    }
}
