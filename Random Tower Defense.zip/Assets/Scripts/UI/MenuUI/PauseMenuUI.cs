﻿using UnityEngine.SceneManagement;
using UnityEngine;

public class PauseMenuUI : MonoBehaviour {
        
    public void ResumeButton()
    {
        //일시정지를 한번더 누르는것과 같은 효과
        PauseButton.SingleTon.Pressed();   
    }
    
    public void RestartButton()
    {
        PauseButton.SingleTon.Pressed();
        SceneManager.LoadScene("StandardMap", LoadSceneMode.Single);
    }

    public void MainMenuButton()
    {
        PauseButton.SingleTon.Pressed();
        SceneManager.LoadScene("MainMenu", LoadSceneMode.Single);
    }






}
