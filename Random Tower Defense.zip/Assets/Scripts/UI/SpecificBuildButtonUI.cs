﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SpecificBuildButtonUI : MonoBehaviour {

    public Tower targetTower;
    public Text nameText;


    private void Start()
    {
        if (nameText != null)
        {
            nameText.text = targetTower.towerName;
            nameText.color = BuildManager.SingleTon.upgradeInfoDic[targetTower.towerType].typeTextColor.color;
        }
        
    }
    public void BuildSpecificTower()
    {
        bool buildSuceed = false;
        buildSuceed = BuildManager.SingleTon.BuildSpecificTower(targetTower);
        //성공시 TileMenuUI닫기
        if (buildSuceed == true)
        {
            TileMenuUI.SingleTon.Close();
        }
    }
}
