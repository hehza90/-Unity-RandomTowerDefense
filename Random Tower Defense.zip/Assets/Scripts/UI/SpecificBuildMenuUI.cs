﻿using UnityEngine;
using System.Collections;

public class SpecificBuildMenuUI : UI {


    public static SpecificBuildMenuUI SingleTon = null;    
    //==========Awake()============
    void Awake()
    {       
        if (SingleTon)
        {
            Destroy(this.gameObject);
            return;
        }
        SingleTon = this;
        Close();
    }   
}
