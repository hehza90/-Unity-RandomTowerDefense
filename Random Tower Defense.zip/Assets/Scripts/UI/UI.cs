﻿using UnityEngine;
using System.Collections;


//플레이어가 컨트롤 하는 UI
public class UI : MonoBehaviour {
    
    public virtual void Open()
    {
        this.gameObject.SetActive(true);
    }

    //Ui닫기
    public virtual void Close()
    {
        this.gameObject.SetActive(false);
    }

    //UI 여닫기 토글
    public virtual void OpenAndCloseToggle()
    {
        if (this.gameObject.activeSelf == true)
        {            
            Close();
            return;
        }
        
        if(this.gameObject.activeSelf == false)
        {
            Open();
            return;
        }
    }



}
