﻿using UnityEditor;
using UnityEngine;


[CustomEditor(typeof(ObjectPoolingManager))]
public class ObjectPoolingInspector : Editor
{
    public override void OnInspectorGUI()
    {
        DrawDefaultInspector();

        if (GUILayout.Button("PoolingObjects"))
        {
            ObjectPoolingManager objectPoolingManager = (ObjectPoolingManager)target;
            objectPoolingManager.PoolingObjects();
        }
    }

}
