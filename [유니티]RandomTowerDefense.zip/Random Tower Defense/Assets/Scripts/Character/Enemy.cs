﻿using UnityEngine;
using System.Collections;
using System;

public class Enemy : Life{

    public float speed=10;
    public float damage= 1;
      
    private Transform moveTarget;    //다음에 갈 위치
    private int waypointIndex = -1;
              

    protected override void OnEnable()
    {
        base.OnEnable();
        whenDisable = null;
        waypointIndex = -1;
        GetNextWaypoint();     
    }
	

	void Update () {

        //타겟까지 거리
        Vector3 dir = moveTarget.position - this.transform.position;
        //이동
        transform.Translate(dir.normalized * speed * Time.deltaTime, Space.World);
        //타겟과 충분히 가까워졌을때 다음 타겟으로
        if(Vector3.Distance(transform.position, moveTarget.position) <= 0.2f)
        {
            GetNextWaypoint();
        }    
    }


    //다음 목적지로
    void GetNextWaypoint()
    {
        if(waypointIndex >= Waypoints.SingleTon.wayPoinList.Count - 1)
        {
            DamageToPlayer();            
            return;
        }

        waypointIndex++;
        moveTarget = Waypoints.SingleTon.wayPoinList[waypointIndex];
        this.transform.LookAt(moveTarget);
    }
     

    void DamageToPlayer()
    {
        Player.SingleTon.ChangeLives(-damage);        
        this.gameObject.SetActive(false);
    }

    public event Action whenDisable;
    void OnDisable()
    {
        if (whenDisable!= null)
        {
            whenDisable();
        }
    }
    
    
}
