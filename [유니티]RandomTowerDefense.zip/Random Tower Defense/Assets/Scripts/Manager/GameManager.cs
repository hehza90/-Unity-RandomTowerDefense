﻿using UnityEngine;
using System.Collections;

public class GameManager : MonoBehaviour {

    private bool gameOver = false;
    public bool GameOver
    {
        get
        {
            return gameOver;
        }       
    }

    private bool gameClear = false;
    public bool GameClear
    {
        get
        {
            return gameClear;
        }
    }


    public GameObject gameOverUI;
    public GameObject gameClearUI;

   


    public static GameManager SingleTon = null;
    
    //============Awake()===============
    void Awake()
    {
        if (SingleTon)
        {
            Destroy(this.gameObject);
            return;
        }
        SingleTon = this;
      
    }


    public void WhenPlayerDie()
    {
        gameOver = true;
        gameOverUI.SetActive(true);
    }

    public void WhenGameClear()
    {
        gameClear = true;
        gameClearUI.SetActive(true);
    }

}
