﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.EventSystems;
using System;


public class Tower : MonoBehaviour {


    public enum TowerType
    {
        A,B,C
    }

    #region UnityInspector

    public string towerName;      //이름   
    public TowerType towerType;  //타워 타입

    [SerializeField]
    private int towerLevel;
    public int TowerLevel
    {
        get
        {
            return towerLevel;
        }
        set
        {
            towerLevel = value;
        }
    }
    public int towerId;          //타워 종류 구별용 ID


    [Header("ATTACK")]
    public float basicDamage;          //기본 공격력
    public float upgradeRateDamage;    //업그레이드에 따라 추가되는 데미지
    public float finalDamage;          //최종 데미지
    public float projectileSpeed;
    public float range = 15f;          //사거리
    public float fireRate = 1f;        //공격 속도
    public GameObject projectilePrefab;
    public Transform firePoint;


    [Header("ROTATION")]
    public Transform partToRotate;
    public float turnSpeed = 10f;


    public GameObject[] colorPart;   //레벨에따라 색깔이 바뀌는 부분
    public SphereCollider rangeCollider;    //타워사정거리 크기의 구형 충돌체

    #endregion UnityInspector


    [NonSerialized]
    public LayerMask targetLayer;
   // [NonSerialized]
    public GameObject targetEnemy;   //공격하고 있는 대상
    [NonSerialized]
    public List<GameObject> enemysInRange =  new List<GameObject>();   //사거리에 있는 적의 리스트

    private Tile underTile;     //이 타워가 지어진 타일 
    public Tile UnderTile
    {
        get
        {
            return underTile;
        }
        set
        {
            underTile = value;
        }
    }    //프로퍼티     

    //판매가격 (0일시 자동 설정)
    [Tooltip("If value 0, Will AutoSet")]
    public float sellCost;

    

    //업그래이드에 따른 데미지 갱신함수, 다른 클래스의 이벤트를 통해 실행
    public void SetDamage()
    {
        finalDamage = basicDamage + (upgradeRateDamage * BuildManager.SingleTon.upgradeInfoDic[towerType].upgradeLevel);
    }

    
    
    //터치&클릭
    void OnMouseDown()
    {
        //위에 상호작용 하는 UI요소가 있는지 확인
        if (Utility.IsPointerOverUIObject() == true)
        {
            return;
        }
        //메뉴 호출 및 대상 설정       
        TowerMenuUI.SingleTon.SetTargetTower(this);      
    }
    

    //============Start()===========
    void Start()
    {
        SetDamage();
        //판매가격을 따로 설정 하지 않았을 경우
        if (sellCost == 0)
        {
            //판매가격 = 0.5 *(basicTowerCost ^ level)
            sellCost = 0.5f * BuildManager.SingleTon.basicTowerCost * (Mathf.Pow(2, towerLevel - 1));
        }     
        rangeCollider.radius = range;
        StartCoroutine(Attack());
    }


    //============Update()===========
    void Update()
    {
        SetTarget();
        if (targetEnemy == null || targetEnemy.activeSelf == false)
        {
            return;
        }

        Vector3 dir = targetEnemy.transform.position - transform.position;
        Quaternion lookRotation = Quaternion.LookRotation(dir);
        Vector3 rotation = Quaternion.Lerp(partToRotate.rotation, lookRotation, Time.deltaTime * turnSpeed).eulerAngles;
        partToRotate.rotation = Quaternion.Euler(0f, rotation.y, 0f);
        
        
    }


    IEnumerator Attack()
    {
        while (true)
        {
            if (targetEnemy == null || targetEnemy.activeSelf==false)
            {
                yield return new WaitUntil(()=>(targetEnemy!= null && targetEnemy.activeSelf==true));
            }
            MakeProjectile();
            yield return new WaitForSeconds(fireRate);
        }
    }

          

    void MakeProjectile()
    {
        GameObject madeObject = ObjectPoolingManager.SingleTon.ActiveGameObject(projectilePrefab, firePoint.transform);
        
        if (madeObject != null)
        {
            Projectile madeProjectile = madeObject.GetComponent<Projectile>();
            madeProjectile.damage = finalDamage;
            madeProjectile.speed = projectileSpeed;
            madeProjectile.SetTarget(targetEnemy);
        }
    }


    public void SetTarget()
    {
        //사정거리 이내에 적이 없다면 return
        if (enemysInRange.Count == 0)
        {
            return;
        }
        //이미 타겟이 있다면
        if (targetEnemy != null && targetEnemy.activeSelf==true)
        {
            return;
        }

        //enemysInRange의 첫번째 요소가 사라져서 null이라면
        if (enemysInRange[0] == null || enemysInRange[0].activeSelf==false)
        {
            enemysInRange.Remove(enemysInRange[0]);
            return;
        }
        targetEnemy = enemysInRange[0];
                
    }


    //사거리만큼 기즈모 그리기
    void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(this.transform.position, range);
    }


}
