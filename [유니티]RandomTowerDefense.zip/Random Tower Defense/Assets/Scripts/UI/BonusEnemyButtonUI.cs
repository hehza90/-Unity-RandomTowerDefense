﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;



public class BonusEnemyButtonUI : MonoBehaviour
{

    public BonusEnemy targetBonusEnemy;
    public Image coolTimeBlackImage;
    private float coolTime;
    private float remainTime;
    
  
    void Awake()
    {              
       //비활성화 상태에서도 시간을 재야하기 때문에 코루틴 대신 Invoke 사용
       //단 검은색 이미지 처리는 화면에 보일때만(활성화 되었을때만)
        InvokeRepeating("CountDown", 0, Time.deltaTime);
        coolTime = targetBonusEnemy.coolTime;
    }
	

    void Update()
    {
        RenewBlackImage();
    }


    //WaveSpawner을 통해 보너스적 스폰, 버튼에 연결
    public void SpwanBonusEnemy()
    {
        if (remainTime > 0)
        {
            return;
        }
        if(WaveSpawner.SingleTon.WavePlaying == true||WaveSpawner.SingleTon.BonusPlaying == true)
        {
            return;
        }
        WaveSpawner.SingleTon.SpawnBonusEnemy(targetBonusEnemy);
        remainTime = coolTime;
    }

    //재사용 대기시간
    void CountDown()
    {
        if(remainTime > 0)
        {
            remainTime -= Time.deltaTime;           
        }
        
    }

    //재사용 대기시간이 남은 비율만큼 검은색 이미지 줄이기(시계방향)
    void RenewBlackImage()
    {
        coolTimeBlackImage.fillAmount = remainTime / coolTime;
    }
}
