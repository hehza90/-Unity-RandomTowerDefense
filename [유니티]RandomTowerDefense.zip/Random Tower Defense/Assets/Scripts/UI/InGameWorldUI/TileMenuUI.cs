﻿using UnityEngine;
using UnityEngine.UI;

public class TileMenuUI : UI {


    #region UnityInspector  

    public Vector3 offset = new Vector3(0, 0.5f, 0);   //UI가 타겟으로부터 떨어져있는정도
    public Text buildButtonText;

    #endregion UnityInspector  



    private Tile targetTile;      //대상 타일
    public Tile TargetTile        //프로퍼티, 외부에서는 읽기 전용
    {
        get
        {
            return targetTile;
        }        
        private set
        {
            targetTile = value;
        }
    }  

      

    public static TileMenuUI SingleTon = null;


    //==========Awake()============
    void Awake()
    {       
        if (SingleTon)
        {
            Destroy(this.gameObject);
            return;
        }
        SingleTon = this;
        Close();
    }

    //==========Start()============
    void Start()
    {
        //빌드가격에 따른 텍스트 변경
        buildButtonText.text = "-" + BuildManager.SingleTon.basicTowerCost.ToString() + "$";

    }

    //타겟 타일 설정 타일 클릭시 실행
    public void SetTargetTile(Tile target)
 	{
        Open();
        TargetTile = target;        
        this.transform.position = TargetTile.transform.position + offset; 		
 	}


    //UI열기
    public override void Open()
    {
        base.Open();
        TowerMenuUI.SingleTon.Close();      
    }


    //타워 짓기
    public void Build()
    {
        bool buildSuceed = false;
        buildSuceed = BuildManager.SingleTon.BuildNewTower(targetTile);
        if (buildSuceed == true)
        {
            Close();
        }
    }

}
